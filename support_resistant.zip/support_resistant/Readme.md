# SaferTrader Web Service

## Description


## How to launch this system
It is recommended to deploy this project using Docker.

### Step1 Install Docker
Docker: https://www.docker.com/

### Step2 Verify the environment variables
In the `docker-compose.yml` file, review all environment variable configurations, including database user information, user data for all data sources, and relevant URLs.

### Step3 Build Docker image and launch by docker-compose
run command
`docker-compose up --build -d`
