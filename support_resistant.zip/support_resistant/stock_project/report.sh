#! /bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

cd /home/thomas/Desktop/safetrader/saferTrader/stock_project
# source env/bin/activate
python3 $PWD/report.py


